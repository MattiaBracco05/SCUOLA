4C Bracco Mattia
· Sito react sul fenomeno dell'ombra della torre civica che si specchia sul campanile della chiesa di San Giovanni ·

CREDITI:
Per realizzare questo sito ho preso spunto dal template "BLK Design System React"
link da cui ho scaricato il template:	https://www.creative-tim.com/product/blk-design-system-react)
Le foto presenti nella prima foto gallery sono state prese da google, mentre quelle nella seconda foto gallery sono state scattate da me durante l'uscita
Il video time-lapse è stato registrato da Leonardo Minetti
Le infomrazioni sul fenomeno sono state prese dagli articoli di giornale della Stampa e di Targato CN mentre quelle riguardanti gli edifici sono state trovate su visitsaluzzo e su paesionline

