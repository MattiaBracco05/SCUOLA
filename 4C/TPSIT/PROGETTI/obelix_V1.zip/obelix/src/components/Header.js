/*
COMPONENTE HEADER
Contiene il titolo e la descrizione del sito, inoltre inserisce 7 quadrat decorativi (quelli che si spostano)
*/
import React from "react";
import { Container } from "reactstrap";

export default function Header() {
  return (
    <div className="page-header header-filter">
      <Container>
        <div className="content-center">
          <h1 className="h1-seo">OBELIX</h1>
          <h3 className="d-sm-block">
            Prenota facilmente il cibo per la tua pausa pranzo
          </h3>
        </div>
      </Container>
    </div>
  );
}
