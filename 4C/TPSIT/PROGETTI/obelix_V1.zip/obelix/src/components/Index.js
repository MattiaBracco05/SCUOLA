import React from "react";

//IMPORTO I VARI COMPONENTI
import Navbar from "./Navbar.js";
import Header from "./Header.js";
import Citta from "./Citta.js";

export default function Index() {
  React.useEffect(() => {
    document.body.classList.toggle("index-page");

    return function cleanup() {
      document.body.classList.toggle("index-page");
    };
  }, []);
  return (
    <>
      {/* NAVBAR (fissa) */}
      <Navbar />
      {/* inizio pagina scorrevole */}
      <div className="wrapper">
        {/* INTESTAZIONE */}
        <Header /> 
        {/* CITTÀ */}
        <Citta />
      </div>
      {/* fine pagina scorrevole */}
    </>
  );
}
