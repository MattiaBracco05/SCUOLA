/*
Questo componente è utilizzato per la scelta del locale 
Chiamata API --> ottengo la lista dei locali --> l'utente sceglie (radio button) --> l'utente clicca sul button --> passo l'ID del locale al file "Prodotti.js"
*/

import React, { useState } from 'react'
import "./Locali.css"
import Prodotti from "./Prodotti.js"

//URL DELL'API
const URL = "http://37.60.34.42:8080/getLocali?citta="

//PARAMETRI (da passare a "Prodotti.js")
let mieiParametri = {
    ID: "000",
    IDLocal: "000",
    READY: "0"
}

const Locali = (props) => {
    console.log("FILE Locali.js il parametro vale: " + props.valori.ID)
    let URL2 = URL + props.valori.ID
    mieiParametri.ID = props.valori.ID

    //USESTATE PER I LOCALI
    const [locali, setLocali] = useState([])

    //FUNZIONE CONNESSIONE (richiamata in automatica)
	const connessione =()=>{
        console.log("FUNZIONE CONNESSIONE (automatico)")

        //FETCH
        fetch(URL2)
        .then((localitext) => localitext.json())
        .then((localiJSON) => {

            //inizialmente azzero la lista contenente i locali
            setLocali([])

            //COMANDO MAP --> ciclo per il numero di locali presenti in quella città
            localiJSON.map((element, index) => {

                setLocali((locali) => [...locali,
                    <div className='row listaLocali'>
                    {/* nome locale */}
                    <div class="col-10 locale">{element.nome}</div>
                    {/* radio button */}
                    <div class="col-2 select"><input type="radio" name="local" value={element.id}/></div>
                </div>])

            })
        })
    }

    //FUNZIONE VEDI LOCALE (richiamata alla pressione del button)
    const vediLocale =()=> {
        console.log("FUNZIONE VEDI LOCALE (pressione button)")
        //ricavo gli elementi (radio button) che hanno il nome "local" 
        var radios = document.getElementsByName('local');
        //imposto il flag a "0" prima di iniziare la ricerca del radio button selezionato
        var flag = 0

        //ciclo per il numero di button radios presenti
        for (var radio of radios) {
            //controllo se il button radio è selezionato
            if (radio.checked) {
                //se è selezionato --> console log con il valore (ID della città) e flag impostato a 1 (trovato)
                console.log("ID locale selezionato: " + radio.value);
                mieiParametri.IDLocal = radio.value
                mieiParametri.READY = 1
                console.log("Il valore salvato nei parametri vale: " + mieiParametri.IDLocal)
                flag = 1
            }
        }

        //se non è stata selezionata nessuna città (flag vale "0") --> messaggio di ERRORE
        if (flag == 0) {
            alert("ERRORE!\nNON È STATO SELEZIONATO NESSUN LOCALE\nÈ necessario selezionare un locale prima di poter visualizzare i suoi dettagli")
        }
    }

    //RETURN --> STAMPA A VIDEO
    return (
        <div>
            {/* RICHIAMO L'API CHE MI RESTITUISCE L'ELENCO DEI LOCALI (automatico) */}
            {connessione()}

            {/* STAMPO L'ELENCO DEI LOCALI */}
            {locali}


            {/* BUTTON PER VISUALIZZARE IL LOCALE SELEZIONATO*/}
            <div className="button">
                <input type="button" className='buttonVisualizza' value="VEDI LOCALE" onClick={vediLocale}/>
            </div>

            {/* PRODOTTI */}
            <Prodotti valori={mieiParametri}/>

        </div>
    )
}

export default Locali