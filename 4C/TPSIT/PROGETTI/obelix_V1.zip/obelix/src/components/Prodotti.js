/*
Questo componente è utilizzato per visualizzare i prodotti
Chiamata API --> ottengo la lista dei prodotti
*/

import React, { useState } from 'react'
import "./Prodotti.css"

//URL DELL'API
const URL = "http://37.60.34.42:8080/getProdotti?citta_id="

const Prodotti = (props) => {

    //USESTATE PER I PRODOTTI
    const [prodotti, setProdotti] = useState([])

    let URL2 = URL + props.valori.ID + "&locali_id=" + props.valori.IDLocal

    //FUNZIONE CONNESSIONE (richiamata in automatica)
	const connessione =()=>{
        console.log("FUNZIONE CONNESSIONE (automatico)")

        //FETCH
        fetch(URL2)
        .then((prodottitext) => prodottitext.json())
        .then((prodottiJSON) => {
            console.log("prodotti NELL'ARRAY:")
            console.log(prodottiJSON)
            console.log(prodottiJSON.cibi[0])

            //determino quanti cibi, quante bevande e quanti menu ci sono
            let nCibi = prodottiJSON.cibi.length
            let nBevande = prodottiJSON.bevande.length
            let nMenu = prodottiJSON.menu.length
            console.log("Numero di cibi: "+ nCibi)
            console.log("Numero di bevande: "+ nBevande)
            console.log("Numero di menù: " + nMenu)

            // console.log(prodottiJSON.cibi[0].nome)

            //inizialmente azzero la lista contenente i prodotti
            setProdotti([])
                  
            //CIBI 
            for (let i=0; i<nCibi; i++) {
                console.log("Valore i (cibi): " + i)
                setProdotti((prodotti) => [...prodotti,
                    <div className='row listaProdotti'>
                        {/* nome prodotto */}
                        <div class="col-4 nome"> <font color="yellow">Cibo: &nbsp;</font> {prodottiJSON.cibi[i].nome}</div>
                        {/* prezzo prodotto */}
                        <div class="col-4 prezzo">{prodottiJSON.cibi[i].prezzo_euro} €</div>
                        {/* check button */}
                        <div class="col-4 select"><input type="checkbox" name="mieiProdotti" value={prodottiJSON.cibi[i].id}></input></div>
                    </div>])
            }

            //BEVANDE
            for (let i=0; i<nBevande; i++) {
                console.log("Valore i (bevande): " + i)
                setProdotti((prodotti) => [...prodotti,
                    <div className='row listaProdotti'>
                        {/* nome prodotto */}
                        <div class="col-4 nome"><font color="blue">Bevanda: &nbsp;</font> {prodottiJSON.bevande[i].nome}</div>
                        {/* prezzo prodotto */}
                        <div class="col-4 prezzo">{prodottiJSON.bevande[i].prezzo_euro} €</div>
                        {/* check button */}
                        <div class="col-4 select"><input type="checkbox" name="mieiProdotti" value={prodottiJSON.bevande[i].id}></input></div>
                    </div>])
            }            

            //MENÙ
            for (let i=0; i<nMenu; i++) {
                console.log("Valore i (menu): " + i)
                setProdotti((prodotti) => [...prodotti,
                    <div className='row listaProdotti'>
                        {/* nome prodotto */}
                        <div class="col-4 nome"><font color="green">Menù: &nbsp;</font> {prodottiJSON.menu[i].nome}</div>
                        {/* prezzo prodotto */}
                        <div class="col-4 prezzo">{prodottiJSON.menu[i].prezzo_euro} €</div>
                        {/* check button */}
                        <div class="col-4 select"><input type="checkbox" name="mieiProdotti" value={prodottiJSON.menu[i].id}></input></div>
                    </div>])
            } 

        })
    }

    //FUNZIONE AGGIUNGI AL CARRELLO (richiamata alla pressione del button)
    const aggiungiAlCarrello =()=> {
        console.log("FUNZIONE AGGIUNGI AL CARRELLO (pressione button)")

        //ricavo gli elementi (check button) che hanno il nome "local" 
        var checkbox = document.getElementsByName('mieiProdotti');
        //imposto il flag a "0" prima di iniziare la ricerca dei check button selezionato
        var flag = 0

        //ciclo per il numero di check button presenti
        for (var check of checkbox) {
            //controllo se il button radio è selezionato
            if (check.checked) {
                //se è selezionato --> console log con il valore (ID del prodotto) e flag impostato a 1 (trovato)
                console.log("ID prodotto selezionato: " + check.value);
                flag = 1
            }
        }

        //se non è stata selezionata nessuna città (flag vale "0") --> messaggio di ERRORE
        if (flag == 0) {
            alert("ERRORE!\nNON È STATO SELEZIONATO NESSUN PRDOTTO\nÈ necessario selezionare almeno un prodotto prima di poter aggiungere qualcosa al carrello")
        }
    }

    //RETURN --> STAMPA A VIDEO
    return (
        <div>
            {/* RICHIAMO L'API CHE MI RESTITUISCE L'ELENCO DEI prodotti (automatico) */}
            {connessione()}

            {/* STAMPO L'ELENCO DEI PRODOTTI */}
            {prodotti}

            {/* BUTTON PER VISUALIZZARE AGGIUNGERE AL CARRELLO*/}
            <div className="button">
                <input type="button" className='buttonVisualizza' value="AGGIUGNI" onClick={aggiungiAlCarrello}/>
            </div>

        </div>
    )
}

export default Prodotti