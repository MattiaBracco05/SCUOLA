/*
Questo componente è utilizzato per la scelta della città
Chiamata API --> ottengo la lista delle città --> l'utente sceglie (radio button) --> l'utente clicca sul button --> passo l'ID della città al file "Locali.js"
*/

import React, { useState, useEffect } from 'react'
import './Citta.css'
import Locali from "./Locali.js"

//URL DELL'API
const URL = "http://37.60.34.42:8080/getCitta"

//PARAMETRI (da passare a "Locali.js")
let mieiParametri = {
    ID: "000"
}

const Citta = () => {	

	//USESTATE PER LE CITTÀ
	const [citta, setCitta] = useState([])

	//FUNZIONE CONNESSIONE (richiamata in automatico)
	const connessione =()=>{
        console.log("FUNZIONE CONNESSIONE (automatico)")

		//FETCH
		fetch(URL)
		.then((cittaText) => cittaText.json())
		.then((cittaJSON) => {
			
            //inizialmente azzero la lista contenente le città
			setCitta([])

			//COMANDO MAP --> ciclo per il numero di città presenti nel file JSON
			cittaJSON.map((element, index) => {
				
				//FUNZIONE FRECCIA CON "...citta" --> mantengo quelle precedenti ed evito che stampi solo l'ultima
				setCitta((citta) => [...citta,
                <div class="row listaCitta">
                    {/* nome città */}
                    <div class="col-4 citta">{element.citta}</div>
                    {/* stemma */}
                    <div class="col-4 stemma"><img src={element.stemma} width="40%"></img></div>
                    {/* radio button */}
                    <div class="col-4 select"><input type="radio" name="city" value={element.id}/></div>
                </div>])
			})
		})
	}

    //FUNZIONE VISUALIZZA LOCALI (richiamata alla pressione del button)
    const visualizzaLocali =()=> {
        console.log("FUNZIONE VISUALIZZA LOCALI (pressione button)")

        //ricavo gli elementi (radio button) che hanno il nome "city" 
        var radios = document.getElementsByName('city');
        //imposto il flag a "0" prima di iniziare la ricerca del radio button selezionato
        var flag = 0

        //ciclo per il numero di button radios presenti
        for (var radio of radios) {
            //controllo se il button radio è selezionato
            if (radio.checked) {
                //se è selezionato --> console log con il valore (ID della città) e flag impostato a 1 (trovato)
                console.log("ID città selezionata: " + radio.value);
                mieiParametri.ID = radio.value
                console.log("Il valore salvato nei parametri vale: " + mieiParametri.ID)
                flag = 1
            }
        }

        //se non è stata selezionata nessuna città (flag vale "0") --> messaggio di ERRORE
        if (flag == 0) {
            alert("ERRORE!\nNON È STATA SELEZIONATA NESSUNA CITTÀ\nÈ necessario selezionare una città prima di poter visualizzare i locali presenti in essa")
        }
    }

    //RETURN --> STAMPA A VIDEO
	return (
	<div>
        {/* RICHIAMO L'API CHE MI RESTITUISCE L'ELENCO DELLE CITTÀ (automatico) */}
		{connessione()} 

        {/* STAMPO L'ELENCO DELLE CITTÀ */}
		{citta}

        {/* BUTTON PER VISUALIZZARE I LOCALI DELLA CITTÀ SELEZIONATA*/}
		<div className="button">
			<input type="button" className='buttonVisualizza' value="MOSTRA LOCALI" onClick={visualizzaLocali}/>
		</div>

        {/* LOCALI */}
		<Locali valori={mieiParametri}/>

	</div>
	)
}

export default Citta