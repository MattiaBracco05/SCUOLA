package com.example.calcolatrice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Variabile dove vado a alvare il valore del 1° numero
    double numero1;
    //Variabile dove salvo l'operazone da effettuare
    String operazioni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Button dei numeri
        Button num0 = findViewById(R.id.num0);
        Button num1 = findViewById(R.id.num1);
        Button num2 = findViewById(R.id.num2);
        Button num3 = findViewById(R.id.num3);
        Button num4 = findViewById(R.id.num4);
        Button num5 = findViewById(R.id.num5);
        Button num6 = findViewById(R.id.num6);
        Button num7 = findViewById(R.id.num7);
        Button num8 = findViewById(R.id.num8);
        Button num9 = findViewById(R.id.num9);

        //Button DEL, "." e "="
        Button del = findViewById(R.id.del);
        Button point = findViewById(R.id.point);
        Button equal = findViewById(R.id.equal);

        //Button operazioni ("+", "-", "x", "/")
        Button piu = findViewById(R.id.piu);
        Button meno = findViewById(R.id.meno);
        Button x = findViewById(R.id.x);
        Button div = findViewById(R.id.div);

        //"Display" della mia calcolatrice
        TextView screen = findViewById(R.id.screen);

        //Button dei numeri
        ArrayList<Button> nums = new ArrayList<>();
        nums.add(num0);
        nums.add(num1);
        nums.add(num2);
        nums.add(num3);
        nums.add(num4);
        nums.add(num5);
        nums.add(num6);
        nums.add(num7);
        nums.add(num8);
        nums.add(num9);

        //Setto lil listener per tutti i button dei numeri
        for (Button b : nums) {
            b.setOnClickListener(view -> {
                if (!screen.getText().toString().equals("0")) {
                    screen.setText(screen.getText().toString() + b.getText().toString());
                } else {
                    screen.setText(b.getText().toString());
                }
            });
        }

        //Button per le operazioni
        ArrayList<Button> opera = new ArrayList<>();
        opera.add(div);
        opera.add(x);
        opera.add(meno);
        opera.add(piu);

        //Setto i listener per tutti i button delle operazioni
        for (Button b : opera) {
            b.setOnClickListener(view -> {
                numero1 = Double.parseDouble(screen.getText().toString());
                operazioni = b.getText().toString();
                screen.setText("0");
            });
        }

        //Listener per la cancellazione dell'ultimo numero (DEL)
        del.setOnClickListener(view -> {
            //Controllo che la stringa sia lunga > 1 (ci deve essere qualcosa di scritto)
            String num = screen.getText().toString();

            //Se sì --> cancello l'ultimo numero
            if (num.length() > 1) {
                screen.setText(num.substring(0, num.length() -1));
            }
            //Altrimenti --> il numero è "0"
            else if (num.length() == 1 && !num.equals("0")) {
                screen.setText("0");
            }
        });

        //Listener del "." per il calcolo decimale
        point.setOnClickListener(view -> {
            if (!screen.getText().toString().contains(".")) {
                screen.setText(screen.getText().toString() + ".");
            }
        });

        //Listener per il calcolo e la stampa del risultato dell'operazione (richiamato dal click del button "=")
        equal.setOnClickListener(view -> {

            //Variabile dove salvo il secondo numero inserito
            double numero2 = Double.parseDouble(screen.getText().toString());
            //Variabile dove salvo il risultato
            double totale;

            //Switch delle operazioni
            switch (operazioni) {
                //Case somma
                case "+":
                    totale = numero1 + numero2;
                    break;

                //Case sottrazione
                case "-":
                    totale = numero1 - numero2;
                    break;

                //Case moltiplicazione
                case "X":
                    totale = numero1 * numero2;
                    break;

                //Case divisione
                case "/":
                    totale = numero1 / numero2;
                    break;

                //Default (eseguo la somma)
                default:
                    totale = numero1 + numero2;
            }
            //Mostro il risulttao dell'operazione
            screen.setText(String.valueOf(totale));
            
            //Importo come primo numero il risultato dell'operazione (in modo da poter fare calcoli aggiuntivi su di esso senza doverlo riscrivere)
            numero1 = totale;
        });
    }
}