import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView display;
    private int result = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        // Metodo 1: Direttamente sul pulsante (Button)
        Button button1 = findViewById(R.id.button_1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendToDisplay("1");
            }
        });

        // Metodo 2: Nel file XML dei componenti
        Button button2 = findViewById(R.id.button_2);
        button2.setOnClickListener(this);

        // Metodo 3: Istanziano un metodo
        Button button3 = findViewById(R.id.button_3);
        button3.setOnClickListener(onClickListener);

        // Metodo 4: Usando un'interfaccia personalizzata
        Button buttonPlus = findViewById(R.id.button_plus);
        buttonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlusButtonClick();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_2:
                appendToDisplay("2");
                break;
        }
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button_3:
                    appendToDisplay("3");
                    break;
            }
        }
    };

    private void onPlusButtonClick() {
        result++;
        display.setText(String.valueOf(result));
    }

    private void appendToDisplay(String text) {
        String currentText = display.getText().toString();
        if (currentText.equals("0")) {
            display.setText(text);
        } else {
            display.setText(currentText + text);
        }
    }
}
